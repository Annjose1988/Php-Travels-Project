package com.PhpTravels.CustomerScripts;

import org.openqa.selenium.WebDriver;

public class AdminBackEndTest {
	 WebDriver driver;

}
